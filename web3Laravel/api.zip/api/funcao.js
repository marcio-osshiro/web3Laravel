var tipo = "novo";
var id = 0;

$(function() {
  buscaDados();
  ativaListagem();
});

function buscaDados() {
  $.getJSON("http://localhost:8000/api/professor", function(data){
    var codigo = '';
    data.forEach(function(item) {
      codigo += `
        <tr>
          <td>${item.id}</td>
          <td>${item.nome}</td>
          <td>${item.email}</td>
          <td><button class='btn btn-danger btn-excluir'>Excluir</button><button class='btn btn-primary btn-editar'>Editar</button>
        </tr>`;
    });
    $('tbody').html(codigo);

    $('.btn-excluir').click(function(event) {
      var id = $(event.target).parent().parent().children().eq(0).text();
      $.ajax( {
        url: `http://localhost:8000/api/professor/${id}`,
        datatype: 'json',
        method: "DELETE"})
      .then(function (data) {
        console.log(data);
        $linha = $(event.target).parent().parent();
        $linha.remove();
      })
      .catch(function (err) {
        console.log(err);
      });
    });
    $('.btn-editar').click(function(event) {
      id = $(event.target).parent().parent().children().eq(0).text();
      nome = $(event.target).parent().parent().children().eq(1).text();
      email = $(event.target).parent().parent().children().eq(2).text();
      $('#nome').val(nome);
      $('#email').val(email);
      tipo = "editar";
      ativaFormulario();
    });
  });
}

function novo() {
  tipo = 'novo';
  $('#nome').val("");
  $('#email').val("");
  ativaFormulario();
  console.log('clicou botao');
}

function cancelar() {
  ativaListagem();
}

function ativaFormulario() {
  $('.formulario').css('display','block');
  $('form').focus();
  $('.listagem').css('display','none');
}

function ativaListagem() {
  $('.listagem').css('display', 'block');
  $('.listagem').focus();
  $('.formulario').css('display', 'none');
}

function gravar() {
    var nome = $('#nome').val();
    var email = $('#email').val();
    data = {
      nome: nome,
      email: email
    };
    if (tipo == "novo") {
      $.post('http://localhost:8000/api/professor', data, function(response) {
          ativaListagem();
          buscaDados();
      }, 'json')
      .catch(function (err) {
        console.log(err.responseText);
      });
    } else {
      $.ajax( {
        url: `http://localhost:8000/api/professor/${id}`,
        datatype: 'json',
        data: data,
        method: "PUT"})
      .then(function (data) {
        console.log(data);
        ativaListagem();
        buscaDados();
      })
      .catch(function (err) {
        console.log(err);
      });
    }
}
