@extends('layouts.main')

@section('content')
    <p>Disciplina de Construção de Páginas Web III. Veremos como criar um sistema utilizando o PHP e o banco de dados MySql.</p>
@endsection
