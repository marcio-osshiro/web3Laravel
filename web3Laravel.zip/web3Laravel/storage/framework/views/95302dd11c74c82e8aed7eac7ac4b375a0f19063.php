<?php $__env->startSection('content'); ?>
  <?php if($errors->any()): ?>
      <div class="alert alert-danger">
          <ul>
              <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <li><?php echo e($error); ?></li>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </ul>
      </div>
  <?php endif; ?>
  <h1>Formulário do Professor</h1>
  <form action="<?php echo e(url('/professor/salva')); ?>" method="post">
    <?php echo csrf_field(); ?>
    <div class="form-group">
      <label for="id">ID</label>
      <input readonly type="text" class="form-control" id="id" name="id" value="<?php echo e($professor->id); ?>">
    </div>
    <div class="form-group">
      <label for="nome">Nome</label>
      <input type="text" class="form-control" id="nome" placeholder="Informe o nome" name="nome" value="<?php echo e(old('nome', $professor->nome)); ?>">
    </div>
    <div class="form-group">
      <label for="area_id">Area</label>
      <select name="area_id" class="custom-select">
        <?php $__currentLoopData = $areas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $area): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <option value="<?php echo e($area->id); ?>" <?php echo e(old('area_id', $professor->area_id) == $area->id? "selected": ""); ?>><?php echo e($area->descricao); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </select>
    </div>
    <div class="form-group">
      <label for="data_nascimento">Data Nascimento</label>
      <input type="date" class="form-control" id="data_nascimento" placeholder="Informe a data nascimento" name="data_nascimento" value="<?php echo e(old('data_nascimento', $professor->data_nascimento)); ?>">
    </div>
    <div class="form-group">
      <label for="salario">Salário</label>
      <input type="number" class="form-control" id="salario" placeholder="Informe o salário" name="salario" value="<?php echo e(old('salario', $professor->salario)); ?>">
    </div>

    <button type="submit" class="btn btn-primary">Salvar</button>
  </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/usuario/laravel6/web3Laravel/resources/views/professor/formulario.blade.php ENDPATH**/ ?>