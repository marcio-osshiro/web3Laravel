<?php $__env->startSection('content'); ?>
    <p>Disciplina de Construção de Páginas Web III. Veremos como criar um sistema utilizando o PHP e o banco de dados MySql.</p>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/usuario/laravel6/web3Laravel/resources/views/index.blade.php ENDPATH**/ ?>