<?php $__env->startSection('content'); ?>
  <h1>Listagem de Professores</h1>
  <a href="/professor/novo" class="btn btn-primary">Novo</a>
  <table class="table table-striped table-bordered">
    <thead>
      <tr>
        <th>ID</th>
        <th>Nome</th>
        <th>Area</th>
        <th>Dt.Nasc.</th>
        <th>Salário</th>
        <th></th>
      </tr>
    </thead>
    <tbody>
      <?php $__currentLoopData = $professores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $professor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
        <td><?php echo e($professor->id); ?></td>
        <td><?php echo e($professor->nome); ?></td>
        <td><?php echo e($professor->area->descricao); ?></td>
        <td><?php echo e(Carbon\Carbon::parse($professor->data_nascimento)->format('d/m/Y')); ?></td>
        <td><?php echo e($professor->salario); ?></td>
        <td>
          <a class='btn btn-primary' href='/professor/edita/<?php echo e($professor->id); ?>'>Editar</a>
          <a class='btn btn-danger' href='/professor/delete/<?php echo e($professor->id); ?>'>Excluir</a>
        </td>
        </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
  </table>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/usuario/laravel6/web3Laravel/resources/views/professor/listagem.blade.php ENDPATH**/ ?>